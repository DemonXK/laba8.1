#pragma once
const int MAX_ENTRIES = 100;
