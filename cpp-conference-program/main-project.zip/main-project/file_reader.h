
#pragma once
#include "conference_entry.h"
#include <vector>
#include <string>

std::vector<ConferenceEntry> readDataFromFile(const std::string& filename);
